"""Reproduce the single-rater pilot metrics from the completed workbook.

Run from the bundle root with: python pilot_analysis.py
The pilot is separate from the synthetic simulation phases in sim.py.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import openpyxl
from scipy.stats import spearmanr
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.ensemble import RandomForestClassifier

import sim

ROOT = Path(__file__).resolve().parent
WORKBOOK = ROOT / "data" / "expert_labeling_sheet_completed_AHP.xlsx"
OUT = ROOT / "results" / "pilot_analysis.json"
SEED = 2026
REPEATS = 20
FOLDS = 5
BOOTSTRAPS = 3000


def load_pilot():
    wb = openpyxl.load_workbook(WORKBOOK, data_only=True, read_only=True)
    ws = wb["Ratings"]
    headers = [ws.cell(4, c).value for c in range(1, 24)]
    df = pd.DataFrame(list(ws.iter_rows(min_row=5, max_row=54, values_only=True)), columns=headers)
    wb.close()
    X = df.iloc[:, 1:20].to_numpy(dtype=float)
    label_map = {"Low": 0, "Moderate": 1, "High": 2}
    y = df["Expert Label"].map(label_map).to_numpy(dtype=int)
    if X.shape != (50, 19) or set(np.unique(y)) != {0, 1}:
        raise ValueError(f"Expected 50 profiles, 19 items and Low/Moderate labels; got {X.shape}, {np.unique(y)}")
    return X, y


def stratified_bootstrap_auc(y, scores, rng):
    by_class = [np.flatnonzero(y == cls) for cls in (0, 1)]
    values = np.empty(BOOTSTRAPS)
    for b in range(BOOTSTRAPS):
        idx = np.concatenate([rng.choice(ids, size=len(ids), replace=True) for ids in by_class])
        values[b] = roc_auc_score(y[idx], scores[idx])
    return [float(x) for x in np.quantile(values, [0.025, 0.975])]


def main():
    X, y = load_pilot()
    rng = np.random.default_rng(SEED)
    n = len(y)
    oof_lr = np.zeros((REPEATS, n), dtype=float)
    oof_rf = np.zeros((REPEATS, n), dtype=float)
    fold_acc = {"LR": [], "RF": []}
    splitter = RepeatedStratifiedKFold(n_splits=FOLDS, n_repeats=REPEATS, random_state=SEED)
    for split_i, (train, test) in enumerate(splitter.split(X, y)):
        rep = split_i // FOLDS
        lr = sim.make_lr().fit(X[train], y[train])
        plr = lr.predict_proba(X[test])[:, 1]
        oof_lr[rep, test] = plr
        fold_acc["LR"].append(accuracy_score(y[test], (plr >= 0.5).astype(int)))
        rf = RandomForestClassifier(n_estimators=sim.RF_TREES, min_samples_leaf=5,
                                    class_weight="balanced", n_jobs=2,
                                    random_state=SEED + split_i).fit(X[train], y[train])
        prf = rf.predict_proba(X[test])[:, 1]
        oof_rf[rep, test] = prf
        fold_acc["RF"].append(accuracy_score(y[test], (prf >= 0.5).astype(int)))
    mean_lr = oof_lr.mean(axis=0)
    mean_rf = oof_rf.mean(axis=0)
    raw, ahp = sim.scores(X)
    result = {
        "source_workbook": WORKBOOK.name,
        "seed": SEED,
        "profiles": n,
        "labels": {"Low": int((y == 0).sum()), "Moderate": int((y == 1).sum())},
        "cv": {
            "folds": FOLDS,
            "repeats": REPEATS,
            "LR_accuracy_mean_pct": round(float(np.mean(fold_acc["LR"]) * 100), 1),
            "LR_accuracy_sd_pct": round(float(np.std(fold_acc["LR"], ddof=1) * 100), 1),
            "RF_accuracy_mean_pct": round(float(np.mean(fold_acc["RF"]) * 100), 1),
            "RF_accuracy_sd_pct": round(float(np.std(fold_acc["RF"], ddof=1) * 100), 1),
            "majority_accuracy_pct": round(float((y == 1).mean() * 100), 1),
            "LR_auc": float(roc_auc_score(y, mean_lr)),
            "RF_auc": float(roc_auc_score(y, mean_rf)),
        },
        "score_auc": {
            "Raw_total": float(roc_auc_score(y, raw)),
            "Raw_total_95pct_bootstrap": stratified_bootstrap_auc(y, raw, rng),
            "AHP_weighted": float(roc_auc_score(y, ahp)),
            "AHP_weighted_95pct_bootstrap": stratified_bootstrap_auc(y, ahp, rng),
            "LR_95pct_bootstrap": stratified_bootstrap_auc(y, mean_lr, rng),
            "RF_95pct_bootstrap": stratified_bootstrap_auc(y, mean_rf, rng),
        },
    }
    # Fit models on all 50 pilot profiles and estimate global mean-absolute Shapley attributions.
    imp_lr, imp_rf, _ = sim.shap_importances(X, y == 1, X, rng, SEED, validate=False)
    item_ahp = np.repeat(sim.AHP_W / np.asarray(sim.DIM_Q), sim.DIM_Q)
    result["shap"] = {}
    for name, importance in (("LR", imp_lr), ("RF", imp_rf)):
        result["shap"][name] = {
            "question_level_spearman_vs_equal_split_AHP": float(spearmanr(importance, item_ahp).statistic),
            "dimension_level_spearman_vs_AHP": float(spearmanr(sim.dim_sum(importance), sim.AHP_W).statistic),
        }
    OUT.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
