#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results figs paper/tables
rm -f results/main.csv results/shap.csv results/shift.csv results/scaling.csv results/ahp_perturbation.json results/ahp_weight_effect.csv results/nonlinear.csv
for phase in main shap shift scaling ahp nonlinear; do
  python sim.py "$phase"
done
python analyze.py
python build_tables.py
python build_paper.py
