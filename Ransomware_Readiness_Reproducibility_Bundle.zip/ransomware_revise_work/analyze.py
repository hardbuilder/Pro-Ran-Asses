"""Aggregate simulation outputs into the numbers, LaTeX tables and figures used in the paper."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
R = str(ROOT / "results")
F = str(ROOT / "figs")
import os
os.makedirs(F, exist_ok=True)
METHODS = ["Raw total", "AHP-weighted", "LR", "RF"]
LABEL = {"Raw total": "Raw total", "AHP-weighted": "AHP-weighted", "LR": "Log. Reg.", "RF": "Rand. Forest"}
COL = {"Raw total": "#444444", "AHP-weighted": "#0072B2", "LR": "#D55E00", "RF": "#009E73"}
MK = {"Raw total": "s", "AHP-weighted": "o", "LR": "^", "RF": "D"}
plt.rcParams.update({"font.size": 8, "font.family": "serif", "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25,
                     "figure.dpi": 200})


def tci(x):
    x = np.asarray(x, float)
    m = x.mean()
    h = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return m, m - h, m + h


summary = {}
# ---------------- main grid ----------------
df = pd.read_csv(f"{R}/main.csv")
df["auc_ext"] = 0.5 * (df.auc_low + df.auc_high)
keys = ["truth", "noise", "balance"]
tab = (df.groupby(keys + ["method"])[["macroF1", "auc_ext"]].mean().unstack("method"))
summary["majority_macroF1"] = {b: float(df[(df.method == "Majority") & (df.balance == b)].macroF1.mean())
                               for b in ["balanced", "imbalanced"]}

# Table: balanced-class macro-F1 and extremes-AUC per truth x noise
lines = []
for truth in ["equal", "ahp", "reversed", "random"]:
    for noise in [0.5, 1.0, 2.0]:
        sub = df[(df.truth == truth) & (df.noise == noise) & (df.balance == "balanced")]
        cells = []
        for m in METHODS:
            f1 = sub[sub.method == m].macroF1.mean()
            auc = sub[sub.method == m].auc_ext.mean()
            cells.append(f"{f1:.3f} / {auc:.3f}")
        lines.append((truth, noise, cells))
summary["main_table_balanced"] = lines

# Paired differences (per replicate), pooled across truth scenarios, by noise level, balanced
diffs = []
for bal in ["balanced", "imbalanced"]:
    for noise in [0.5, 1.0, 2.0]:
        for truth in ["equal", "ahp", "reversed", "random"]:
            sub = df[(df.truth == truth) & (df.noise == noise) & (df.balance == bal)]
            p = sub.pivot(index="rep", columns="method", values=["macroF1", "auc_ext"])
            for a, b in [("RF", "Raw total"), ("LR", "Raw total"), ("AHP-weighted", "Raw total"),
                         ("RF", "LR"), ("AHP-weighted", "LR")]:
                for met in ["macroF1", "auc_ext"]:
                    d = (p[met][a] - p[met][b]).values
                    m, lo, hi = tci(d)
                    diffs.append(dict(balance=bal, noise=noise, truth=truth, a=a, b=b, metric=met,
                                      mean=m, lo=lo, hi=hi, excl0=bool(lo > 0 or hi < 0)))
dd = pd.DataFrame(diffs)
dd.to_csv(f"{R}/paired_differences.csv", index=False)
summary["n_paired_cells"] = int(len(dd))
frac = {}
for (a, b, met), g in dd.groupby(["a", "b", "metric"]):
    frac[f"{a} vs {b} | {met}"] = dict(cells=int(len(g)), ci_excludes_zero=int(g.excl0.sum()),
                                      mean_diff=float(g["mean"].mean()),
                                      min_diff=float(g["mean"].min()), max_diff=float(g["mean"].max()))
summary["paired_summary"] = frac

# Which method wins most often (mean macro-F1 among 4) per scenario
best = []
for (t, n, b), g in df[df.method.isin(METHODS)].groupby(keys):
    m = g.groupby("method").macroF1.mean()
    best.append(m.idxmax())
summary["best_method_counts"] = pd.Series(best).value_counts().to_dict()

# AHP-weighted vs Raw when truth matches / mismatches (balanced, noise 1.0)
sel = dd[(dd.balance == "balanced") & (dd.noise == 1.0) & (dd.a == "AHP-weighted") & (dd.b == "Raw total")]
summary["ahp_vs_raw_noise1"] = sel[["truth", "metric", "mean", "lo", "hi"]].round(4).to_dict("records")

# overall pooled metric levels
pool = df[df.balance == "balanced"].groupby(["noise", "method"])[["macroF1", "auc_ext"]].mean().round(3)
summary["pooled_balanced"] = {f"{n}|{m}": v for (n, m), v in pool.to_dict("index").items()}
poolI = df[df.balance == "imbalanced"].groupby(["noise", "method"])[["macroF1", "auc_ext"]].mean().round(3)
summary["pooled_imbalanced"] = {f"{n}|{m}": v for (n, m), v in poolI.to_dict("index").items()}

# Figure A: macro-F1 vs noise by truth (balanced)
fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.1), sharey=True)
for ax, truth in zip(axes, ["equal", "ahp", "reversed", "random"]):
    for m in METHODS:
        xs, ys, lo, hi = [], [], [], []
        for ni, noise in enumerate([0.5, 1.0, 2.0]):
            v = df[(df.truth == truth) & (df.noise == noise) & (df.balance == "balanced") & (df.method == m)].macroF1
            mm, l, h = tci(v)
            xs.append(ni); ys.append(mm); lo.append(mm - l); hi.append(h - mm)
        off = {"Raw total": -0.09, "AHP-weighted": -0.03, "LR": 0.03, "RF": 0.09}[m]
        ax.errorbar(np.array(xs) + off, ys, yerr=[lo, hi], color=COL[m], marker=MK[m], ms=3.5,
                    lw=1, capsize=1.5, label=LABEL[m])
    ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["0.5", "1", "2"])
    ax.set_title(f"truth: {truth}", fontsize=8)
    ax.set_xlabel("outcome noise ratio")
axes[0].set_ylabel("macro-F1 (3 classes)")
axes[0].legend(fontsize=6.5, frameon=False, loc="lower left")
fig.tight_layout()
fig.savefig(f"{F}/fig_main.pdf"); fig.savefig(f"{F}/fig_main.png")
plt.close(fig)

# ---------------- shift ----------------
sh = pd.read_csv(f"{R}/shift.csv")
sh["auc_ext"] = 0.5 * (sh.auc_low + sh.auc_high)
shift_rows = []
for m in METHODS:
    a = sh[(sh.method == m) & (sh.setting == "in-distribution")].set_index("rep")
    b = sh[(sh.method == m) & (sh.setting.str.startswith("shifted"))].set_index("rep")
    for met in ["macroF1", "auc_ext"]:
        id_m = tci(a[met])[0]
        sh_m = tci(b[met])[0]
        dm, lo, hi = tci((b[met] - a[met]).values)
        shift_rows.append(dict(method=m, metric=met, in_dist=id_m, shifted=sh_m, delta=dm, lo=lo, hi=hi))
summary["shift"] = shift_rows

# ---------------- scaling ----------------
sc = pd.read_csv(f"{R}/scaling.csv")
sc["auc_ext"] = 0.5 * (sc.auc_low + sc.auc_high)
scal = sc.groupby(["n", "method"])[["macroF1", "auc_ext"]].mean().round(3)
summary["scaling"] = {f"{n}|{m}": v for (n, m), v in scal.to_dict("index").items()}
# between-replicate SD of macro-F1 at n=200 vs 5000
summary["scaling_sd"] = {f"{n}|{m}": float(sc[(sc.n == n) & (sc.method == m)].macroF1.std())
                         for n in [200, 5000] for m in METHODS}

# ---------------- shap ----------------
sp = pd.read_csv(f"{R}/shap.csv")
shap_rows = []
for truth in ["equal", "ahp", "reversed", "random"]:
    for model in ["LR", "RF"]:
        g = sp[(sp.truth == truth) & (sp.model == model)]
        r = dict(truth=truth, model=model)
        for col in ["rho_dim_truth", "rho_dim_ahp", "rho_q_ahp", "truth_vs_ahp"]:
            v = g[col].dropna()
            if len(v) > 1 and v.std() > 0:
                m, lo, hi = tci(v)
                r[col] = (m, lo, hi)
            else:
                r[col] = (float(v.mean()) if len(v) else np.nan, np.nan, np.nan)
        shap_rows.append(r)
summary["shap"] = shap_rows
try:
    summary["shap_validation"] = json.load(open(f"{R}/shap_validation.json"))
except Exception:
    pass

# Figure B: SHAP-truth and SHAP-AHP dimension-level Spearman
fig, ax = plt.subplots(figsize=(3.5, 2.4))
truths = ["equal", "ahp", "reversed", "random"]
xpos = np.arange(len(truths))
for k, (model, off) in enumerate([("LR", -0.2), ("RF", 0.2)]):
    for col, ls, fill in [("rho_dim_truth", "-", True), ("rho_dim_ahp", "--", False)]:
        ys, lo, hi = [], [], []
        for truth in truths:
            v = sp[(sp.truth == truth) & (sp.model == model)][col].dropna()
            mm, l, h = tci(v) if v.std() > 0 else (v.mean(), v.mean(), v.mean())
            ys.append(mm); lo.append(mm - l); hi.append(h - mm)
        shift = off + (0.0 if col == "rho_dim_truth" else 0.07)
        ax.errorbar(xpos + shift, ys, yerr=[lo, hi], fmt=("o" if fill else "s"), color=COL[model], ms=3.5,
                    mfc=(COL[model] if fill else "white"), capsize=1.5, lw=1,
                    label=f"{LABEL[model]} vs {'true weights' if fill else 'AHP weights'}")
ax.axhline(0, color="k", lw=0.5)
ax.set_xticks(xpos); ax.set_xticklabels(["equal", "AHP-like", "reversed", "random"])
ax.set_xlabel("generating (true) dimension weights"); ax.set_ylabel("Spearman ρ (8 dimensions)")
ax.legend(fontsize=5.5, frameon=False, ncol=2, loc="lower center", bbox_to_anchor=(0.5, 1.0))
fig.tight_layout()
fig.savefig(f"{F}/fig_shap.pdf"); fig.savefig(f"{F}/fig_shap.png")
plt.close(fig)

# ---------------- AHP ----------------
ap = json.load(open(f"{R}/ahp_perturbation.json"))
summary["ahp_perturbation"] = ap["perturbation"]
aw = pd.read_csv(f"{R}/ahp_weight_effect.csv")
wrows = []
for truth in ["equal", "ahp", "reversed"]:
    g = aw[aw.truth == truth]
    wrows.append(dict(truth=truth, auc_equal=g.auc_equal.mean(), auc_ahp=g.auc_ahp.mean(),
                      auc_oracle=g.auc_oracle.mean(),
                      pert_mean=g.pert_mean.mean(), pert_min=g.pert_min.mean(), pert_max=g.pert_max.mean(),
                      dir_mean=g.dir_mean.mean(), dir_min=g.dir_min.mean(), dir_max=g.dir_max.mean()))
summary["weight_effect"] = wrows

# Figure C: perturbed weight intervals (sigma=0.4)
p4 = [p for p in ap["perturbation"] if p["sigma"] == 0.4][0]
names = ["Backup", "IAM", "Endpoint", "Patch", "Network", "Monitor.", "IR/BC", "Aware."]
fig, ax = plt.subplots(figsize=(3.5, 2.3))
x = np.arange(8)
lo, hi, mu = np.array(p4["w_lo"]), np.array(p4["w_hi"]), np.array(p4["w_mean"])
ax.vlines(x, lo, hi, color="#0072B2", lw=3, alpha=0.6, label="95% range, σ=0.4")
ax.plot(x, mu, "o", color="#0072B2", ms=3, label="perturbed mean")
ax.plot(x, ap["base_weights"], "kx", ms=4, label="pilot AHP weight")
ax.set_xticks(x); ax.set_xticklabels(names, rotation=35, ha="right")
ax.set_ylabel("dimension weight"); ax.legend(fontsize=6, frameon=False)
fig.tight_layout()
fig.savefig(f"{F}/fig_ahp.pdf"); fig.savefig(f"{F}/fig_ahp.png")
plt.close(fig)

json.dump(summary, open(f"{R}/summary.json", "w"), indent=1, default=float)
print("analysis written")
