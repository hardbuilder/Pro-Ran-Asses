"""Inline generated tables into main.tex and compile (\\input has a lookahead problem with trailing \\\\)."""
import re, subprocess, os
from pathlib import Path
ROOT = Path(__file__).resolve().parent
os.chdir(ROOT / "paper")
src = open("main.tex").read()
src = re.sub(r"\\input\{tables/(\w+)\}", lambda m: open(f"tables/{m.group(1)}.tex").read().rstrip("\n"), src)
open("paper_built.tex", "w").write(src)
for _ in range(2):
    r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "paper_built.tex"], capture_output=True, text=True, errors="replace")
log_text = Path("paper_built.log").read_text(errors="replace") if Path("paper_built.log").exists() else r.stdout
errs = [l for l in log_text.splitlines() if l.startswith("!")]
warn = [l for l in log_text.splitlines() if ("LaTeX Warning:" in l or "Overfull" in l or "Underfull" in l or "multiply defined" in l or "undefined" in l.lower())]
print("errors:", errs[:5]); print("warnings:", warn[:15])
