"""
Simulation study for the ransomware-readiness assessment pipeline.

Phases (python sim.py <phase>):
  main     - model/score comparison across truth-weight x noise x class-balance scenarios
  shap     - Shapley-value importance vs. the generating (true) dimension weights and AHP weights
  shift    - train on medium/large organisations, test on small organisations
  scaling  - performance as a function of dataset size
  ahp      - Monte Carlo sensitivity of AHP weights and of the weighted score

All outcomes are produced by a latent-variable generator whose outcome model is independent of the
raw questionnaire total (labels are NOT a deterministic function of the 19 items).
Every number reported in the paper comes from the CSV/JSON files written here.
"""
import sys, json, time, os
from pathlib import Path
import numpy as np
import pandas as pd
import openpyxl
from scipy.stats import spearmanr, kendalltau
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score

ROOT = Path(__file__).resolve().parent
OUT = str(ROOT / "results")
WORKBOOK = ROOT / "data" / "expert_labeling_sheet_completed_AHP.xlsx"
DIM_Q = [3, 3, 2, 2, 2, 2, 3, 2]
DIM_NAMES = ["Backup", "IAM", "Endpoint", "Patch/Vuln", "Network", "Monitoring", "IR/BC", "Awareness"]
DIM_IDX = np.repeat(np.arange(8), DIM_Q)
# Load the actual single-rater pairwise judgments; dimension order is fixed by DIM_NAMES.
AHP_DIMENSIONS = [
    "Backup & Recovery",
    "Identity & Access Mgmt (incl. privileged access)",
    "Endpoint Security",
    "Patch / Vulnerability Mgmt",
    "Network Segmentation",
    "Security Monitoring",
    "Incident Response & Business Continuity",
    "Security Awareness",
]

def load_ahp_matrix(path=WORKBOOK):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb["AHP_Weights"]
    matrix = np.ones((8, 8), dtype=float)
    answered = 0
    for row in range(5, 33):
        a, b, more, strength = (ws.cell(row, col).value for col in (2, 3, 4, 5))
        if a is None or b is None or more is None or strength is None:
            continue
        i, j = AHP_DIMENSIONS.index(a), AHP_DIMENSIONS.index(b)
        strength = float(strength)
        ratio = 1.0 if more == "Equal" else (strength if more == "A" else 1.0 / strength)
        matrix[i, j], matrix[j, i] = ratio, 1.0 / ratio
        answered += 1
    wb.close()
    if answered != 28:
        raise ValueError(f"Expected 28 completed AHP comparisons in {path}; found {answered}")
    return matrix

def ahp_from_matrix(A):
    # Power iteration is deterministic and much faster than a general eigensolver
    # for the thousands of positive reciprocal matrices in the Monte Carlo loop.
    w = np.full(A.shape[0], 1.0 / A.shape[0])
    for _ in range(100):
        nxt = A @ w
        nxt /= nxt.sum()
        if np.max(np.abs(nxt - w)) < 1e-13:
            w = nxt
            break
        w = nxt
    lam = float(np.mean((A @ w) / w))
    return w, lam

AHP_MATRIX = load_ahp_matrix()
AHP_W, AHP_LAMBDA_MAX = ahp_from_matrix(AHP_MATRIX)
AHP_CR = ((AHP_LAMBDA_MAX - 8) / 7) / 1.41
assert abs(AHP_W.sum() - 1) < 1e-9
SIZES = {"small": dict(shift=-0.35, rho=0.65),
         "medium": dict(shift=0.0, rho=0.55),
         "large": dict(shift=0.35, rho=0.45)}
SIZE_MIX = (0.4, 0.4, 0.2)
THR = np.array([-0.95, -0.15, 0.75])
N_DEFAULT = 3000
R_DEFAULT = 10
RF_TREES = 150


def truth_weights(kind, rng):
    if kind == "equal":
        return np.full(8, 1 / 8)
    if kind == "ahp":
        return AHP_W.copy()
    if kind == "reversed":
        order = np.argsort(AHP_W)
        w = np.empty(8)
        w[order] = np.sort(AHP_W)[::-1]
        return w
    if kind == "random":
        return rng.dirichlet(np.ones(8))
    raise ValueError(kind)


def gen_profiles(n, rng, beta, noise, props, mix=SIZE_MIX, nl_mix=0.0):
    names = list(SIZES)
    size = rng.choice(3, size=n, p=mix)
    shift = np.array([SIZES[k]["shift"] for k in names])[size]
    rho = np.array([SIZES[k]["rho"] for k in names])[size]
    g = shift + rng.standard_normal(n)
    d = rho[:, None] * g[:, None] + np.sqrt(1 - rho ** 2)[:, None] * rng.standard_normal((n, 8))
    z = (0.68 * d[:, DIM_IDX] + 0.22 * g[:, None]
         + np.sqrt(1 - 0.68 ** 2 - 0.22 ** 2) * rng.standard_normal((n, 19)))
    X = (z[:, :, None] > THR).sum(axis=2)
    s = d @ beta
    if nl_mix > 0:  # blend of the additive weighted sum and a weakest-link term (min over dimension factors)
        zl = (s - s.mean()) / s.std()
        mn = d.min(axis=1)
        zm = (mn - mn.mean()) / mn.std()
        s = (1 - nl_mix) * zl + nl_mix * zm
    y_lat = s + noise * s.std() * rng.standard_normal(n)
    q1, q2 = np.quantile(y_lat, [props[0], props[0] + props[1]])
    y = np.where(y_lat <= q1, 0, np.where(y_lat <= q2, 1, 2))
    return X.astype(float), y, size, d


def scores(X, w_dim=AHP_W):
    S = X / 3 * 100
    raw = S.mean(1)
    dm = np.stack([S[:, DIM_IDX == j].mean(1) for j in range(8)], 1)
    return raw, dm @ w_dim


def make_lr():
    from sklearn.pipeline import make_pipeline
    return make_pipeline(StandardScaler(),
                         LogisticRegression(C=1.0, max_iter=3000, class_weight="balanced"))


def make_rf(seed):
    return RandomForestClassifier(n_estimators=RF_TREES, min_samples_leaf=5, class_weight="balanced",
                                  n_jobs=1, random_state=seed)


def score_to_class(tr_score, tr_y, te_score):
    props = np.bincount(tr_y, minlength=3) / len(tr_y)
    q1, q2 = np.quantile(tr_score, [props[0], props[0] + props[1]])
    return np.where(te_score <= q1, 0, np.where(te_score <= q2, 1, 2))


def metrics_from(y, pred, p_low, p_high):
    return dict(macroF1=f1_score(y, pred, average="macro", labels=[0, 1, 2], zero_division=0),
                acc=accuracy_score(y, pred),
                auc_low=roc_auc_score(y == 0, p_low), auc_high=roc_auc_score(y == 2, p_high))


def eval_methods(Xtr, ytr, Xte, yte, seed):
    """Fit on train, evaluate on test. Returns {method: (pred, p_low, p_high)}."""
    out = {}
    lr = make_lr().fit(Xtr, ytr)
    p = lr.predict_proba(Xte)
    out["LR"] = (p.argmax(1), p[:, 0], p[:, 2])
    rf = make_rf(seed).fit(Xtr, ytr)
    p = rf.predict_proba(Xte)
    out["RF"] = (p.argmax(1), p[:, 0], p[:, 2])
    rt, at = scores(Xtr)
    re, ae = scores(Xte)
    out["Raw total"] = (score_to_class(rt, ytr, re), -re, re)
    out["AHP-weighted"] = (score_to_class(at, ytr, ae), -ae, ae)
    maj = np.bincount(ytr, minlength=3).argmax()
    out["Majority"] = (np.full(len(yte), maj), np.full(len(yte), 0.5), np.full(len(yte), 0.5))
    return out


def cv_eval(X, y, seed, k=5, eval_mask=None):
    skf = StratifiedKFold(k, shuffle=True, random_state=seed)
    n = len(y)
    store = {}
    for tr, te in skf.split(X, y):
        res = eval_methods(X[tr], y[tr], X[te], y[te], seed)
        for m, (pr, pl, ph) in res.items():
            if m not in store:
                store[m] = [np.zeros(n, int), np.zeros(n), np.zeros(n)]
            store[m][0][te], store[m][1][te], store[m][2][te] = pr, pl, ph
    rows = {}
    mask = np.ones(n, bool) if eval_mask is None else eval_mask
    for m, (pr, pl, ph) in store.items():
        rows[m] = metrics_from(y[mask], pr[mask], pl[mask], ph[mask])
    return rows


PROPS = {"balanced": (1 / 3, 1 / 3, 1 / 3), "imbalanced": (0.2, 0.5, 0.3)}


def phase_main():
    t0 = time.time()
    out_path = f"{OUT}/main.csv"
    if os.path.exists(out_path):
        rows = pd.read_csv(out_path).to_dict("records")
        completed = {(str(r["truth"]), float(r["noise"]), str(r["balance"]), int(r["rep"])) for r in rows if r["method"] == "Majority"}
    else:
        rows, completed = [], set()
    scn = 0
    for truth in ["equal", "ahp", "reversed", "random"]:
        for noise in [0.5, 1.0, 2.0]:
            for bal in ["balanced", "imbalanced"]:
                scn += 1
                for rep in range(R_DEFAULT):
                    key = (truth, float(noise), bal, rep)
                    if key in completed:
                        continue
                    seed = 42 + 1000 * rep + 10 * scn
                    rng = np.random.default_rng(seed)
                    beta = truth_weights(truth, rng)
                    X, y, size, d = gen_profiles(N_DEFAULT, rng, beta, noise, PROPS[bal])
                    print(f"main scn {scn}/24 rep {rep+1} fitting", flush=True)
                    res = cv_eval(X, y, seed)
                    print(f"main scn {scn}/24 rep {rep+1} evaluated", flush=True)
                    for m, r in res.items():
                        rows.append(dict(truth=truth, noise=noise, balance=bal, rep=rep, method=m, **r))
                    completed.add(key)
                    pd.DataFrame(rows).to_csv(out_path, index=False)
                    print(f"main scn {scn}/24 rep {rep+1}/{R_DEFAULT} checkpointed ({time.time()-t0:.0f}s)", flush=True)


# ---------- Shapley values ----------
def sampling_shapley(f, Xexp, Xbg, rng, n_perm=100):
    """Permutation-sampling (interventional) Shapley estimator with random background rows."""
    n, p = Xexp.shape
    phi = np.zeros((n, p))
    steps = np.arange(p + 1)
    for r in range(n):
        x = Xexp[r]
        order = np.argsort(rng.random((n_perm, p)), axis=1)
        rank = np.argsort(order, axis=1)
        bg = Xbg[rng.integers(0, len(Xbg), n_perm)]
        mask = rank[:, None, :] < steps[None, :, None]
        H = np.where(mask, x[None, None, :], bg[:, None, :]).reshape(-1, p)
        pred = f(H).reshape(n_perm, p + 1)
        contrib = np.zeros((n_perm, p))
        np.put_along_axis(contrib, order, pred[:, 1:] - pred[:, :-1], axis=1)
        phi[r] = contrib.mean(0)
    return phi


def shap_importances(Xtr, ytr_bin, Xexp, rng, seed, validate=False):
    sc = StandardScaler().fit(Xtr)
    Ztr, Zexp = sc.transform(Xtr), sc.transform(Xexp)
    lr = LogisticRegression(C=1.0, max_iter=3000, class_weight="balanced").fit(Ztr, ytr_bin)
    phi_lr = lr.coef_[0][None, :] * (Zexp - Ztr.mean(0))  # exact interventional values, log-odds scale
    imp_lr = np.abs(phi_lr).mean(0)
    rf = RandomForestClassifier(n_estimators=RF_TREES, min_samples_leaf=5, class_weight="balanced",
                                n_jobs=1, random_state=seed).fit(Xtr, ytr_bin)
    phi_rf = sampling_shapley(lambda A: rf.predict_proba(A)[:, 1], Xexp, Xtr, rng)
    imp_rf = np.abs(phi_rf).mean(0)
    val = None
    if validate:
        phi_s = sampling_shapley(lambda A: lr.decision_function(sc.transform(A)), Xexp[:60], Xtr, rng)
        imp_s = np.abs(phi_s).mean(0)
        imp_c = np.abs(phi_lr[:60]).mean(0)
        val = dict(spearman=float(spearmanr(imp_s, imp_c)[0]),
                   mean_rel_err=float(np.mean(np.abs(imp_s - imp_c) / imp_c)))
    return imp_lr, imp_rf, val


def dim_sum(imp):
    return np.array([imp[DIM_IDX == j].sum() for j in range(8)])


def phase_shap():
    rows, vals = [], []
    t0 = time.time()
    for ti, truth in enumerate(["equal", "ahp", "reversed", "random"]):
        for rep in range(R_DEFAULT):
            seed = 7000 + 1000 * rep + 10 * ti
            rng = np.random.default_rng(seed)
            beta = truth_weights(truth, rng)
            X, y, size, d = gen_profiles(N_DEFAULT, rng, beta, 1.0, PROPS["balanced"])
            yb = (y == 0).astype(int)  # Low readiness vs rest
            idx = rng.choice(len(y), 150, replace=False)
            il, ir, val = shap_importances(X, yb, X[idx], rng, seed, validate=(ti == 0 and rep == 0))
            if val:
                vals.append(val)
            fw_q = (AHP_W / np.array(DIM_Q))[DIM_IDX]  # equal-split framework weights per question
            for name, imp in [("LR", il), ("RF", ir)]:
                dsh = dim_sum(imp)
                rows.append(dict(truth=truth, rep=rep, model=name,
                                 rho_dim_truth=spearmanr(dsh, beta)[0],
                                 tau_dim_truth=kendalltau(dsh, beta)[0],
                                 rho_dim_ahp=spearmanr(dsh, AHP_W)[0],
                                 tau_dim_ahp=kendalltau(dsh, AHP_W)[0],
                                 rho_q_ahp=spearmanr(imp, fw_q)[0],
                                 truth_vs_ahp=spearmanr(beta, AHP_W)[0],
                                 shares=json.dumps((dsh / dsh.sum()).round(5).tolist()),
                                 beta=json.dumps(beta.round(5).tolist())))
        print(f"shap {truth} done {time.time()-t0:.0f}s", flush=True)
        pd.DataFrame(rows).to_csv(f"{OUT}/shap.csv", index=False)
    json.dump(vals, open(f"{OUT}/shap_validation.json", "w"))


def phase_nonlinear():
    rows = []
    scn = 0
    for truth in ["equal", "ahp"]:
        for nl in [0.5, 1.0]:
            for noise in [0.5, 1.0]:
                scn += 1
                for rep in range(R_DEFAULT):
                    seed = 13000 + 1000 * rep + 10 * scn
                    rng = np.random.default_rng(seed)
                    beta = truth_weights(truth, rng)
                    X, y, size, d = gen_profiles(N_DEFAULT, rng, beta, noise, PROPS["balanced"], nl_mix=nl)
                    res = cv_eval(X, y, seed)
                    for m, r in res.items():
                        rows.append(dict(truth=truth, nl_mix=nl, noise=noise, rep=rep, method=m, **r))
                print(f"nonlinear scn {scn}/8", flush=True)
    pd.DataFrame(rows).to_csv(f"{OUT}/nonlinear.csv", index=False)


def phase_shift():
    rows = []
    for rep in range(R_DEFAULT):
        seed = 9000 + 1000 * rep
        rng = np.random.default_rng(seed)
        beta = truth_weights("equal", rng)
        X, y, size, d = gen_profiles(N_DEFAULT, rng, beta, 1.0, PROPS["balanced"])
        small = size == 0
        idr = cv_eval(X, y, seed, eval_mask=small)  # in-distribution: CV over all orgs, scored on small orgs
        res = eval_methods(X[~small], y[~small], X[small], y[small], seed)  # shifted: train w/o small orgs
        for m in idr:
            rows.append(dict(rep=rep, setting="in-distribution", method=m, **idr[m]))
            pr, pl, ph = res[m]
            rows.append(dict(rep=rep, setting="shifted (train medium+large)", method=m,
                             **metrics_from(y[small], pr, pl, ph)))
        print(f"shift rep {rep}", flush=True)
    pd.DataFrame(rows).to_csv(f"{OUT}/shift.csv", index=False)


def phase_scaling():
    rows = []
    for n in [200, 500, 1000, 3000, 5000]:
        for rep in range(R_DEFAULT):
            seed = 11000 + 1000 * rep + n
            rng = np.random.default_rng(seed)
            beta = truth_weights("equal", rng)
            X, y, size, d = gen_profiles(n, rng, beta, 1.0, PROPS["balanced"])
            res = cv_eval(X, y, seed)
            for m, r in res.items():
                rows.append(dict(n=n, rep=rep, method=m, **r))
        print(f"scaling n={n}", flush=True)
        pd.DataFrame(rows).to_csv(f"{OUT}/scaling.csv", index=False)


def phase_ahp():
    n = 8
    RI = 1.41
    # Perturb the actual reciprocal judgment matrix from the workbook, not a
    # perfectly consistent matrix reconstructed from its derived weights.
    base = AHP_MATRIX.copy()
    out = {"perturbation": [], "base_weights": AHP_W.round(10).tolist(),
           "base_lambda_max": float(AHP_LAMBDA_MAX), "base_CR": float(AHP_CR),
           "source_workbook": "data/expert_labeling_sheet_completed_AHP.xlsx",
           "perturbation_method": "independent lognormal multiplicative noise on each of the 28 upper-triangle judgments; reciprocals reset"}
    rng = np.random.default_rng(2026)
    base_rank = np.argsort(np.argsort(-AHP_W))
    top3 = set(np.argsort(-AHP_W)[:3])
    perturbed_by_sigma = {}
    for sigma in [0.2, 0.4, 0.6]:
        W, CR = [], []
        for _ in range(2000):
            A = base.copy()
            for i in range(n):
                for j in range(i + 1, n):
                    f = np.exp(sigma * rng.standard_normal())
                    A[i, j] = base[i, j] * f
                    A[j, i] = 1 / A[i, j]
            w, lam = ahp_from_matrix(A)
            W.append(w)
            CR.append((lam - n) / (n - 1) / RI)
        W, CR = np.array(W), np.array(CR)
        taus = [kendalltau(w, AHP_W)[0] for w in W]
        out["perturbation"].append(dict(
            sigma=sigma, mean_CR=float(CR.mean()), frac_CR_lt_0p10=float((CR < 0.10).mean()),
            mean_tau=float(np.mean(taus)),
            top3_unchanged=float(np.mean([set(np.argsort(-w)[:3]) == top3 for w in W])),
            w_mean=W.mean(0).round(4).tolist(),
            w_lo=np.percentile(W, 2.5, axis=0).round(4).tolist(),
            w_hi=np.percentile(W, 97.5, axis=0).round(4).tolist()))
        perturbed_by_sigma[sigma] = W[CR < 0.10]
        print(f"AHP perturbation sigma={sigma} complete; acceptable={len(perturbed_by_sigma[sigma])}", flush=True)
    json.dump(out, open(f"{OUT}/ahp_perturbation.json", "w"), indent=1)
    # Checkpoint the comparatively expensive AUC sensitivity draws so the run
    # can resume cleanly if a constrained runtime interrupts it.
    effect_path = f"{OUT}/ahp_weight_effect.csv"
    if os.path.exists(effect_path):
        old = pd.read_csv(effect_path)
        rows = old.to_dict("records")
        completed = {(str(r["truth"]), int(r["rep"])) for r in rows}
    else:
        rows, completed = [], set()
    for truth in ["equal", "ahp", "reversed"]:
        for rep in range(R_DEFAULT):
            if (truth, rep) in completed:
                continue
            seed = 15000 + 1000 * rep + 10 * ["equal", "ahp", "reversed"].index(truth)
            r2 = np.random.default_rng(seed)
            beta = truth_weights(truth, r2)
            X, y, size, d = gen_profiles(N_DEFAULT, r2, beta, 1.0, PROPS["balanced"])

            # Precompute dimension means once per synthetic replicate; only the
            # eight-element weight vector changes across the sensitivity draws.
            S = X / 3 * 100
            dm = np.stack([S[:, DIM_IDX == j].mean(1) for j in range(8)], 1)
            def ext_auc(w):
                s = dm @ w
                return 0.5 * (roc_auc_score(y == 0, -s) + roc_auc_score(y == 2, s))
            Wp = perturbed_by_sigma[0.4]
            pert = [ext_auc(w) for w in Wp[r2.choice(len(Wp), 200)]]
            dirich = [ext_auc(r2.dirichlet(np.ones(8))) for _ in range(200)]
            rows.append(dict(truth=truth, rep=rep, auc_equal=ext_auc(np.full(8, 1 / 8)),
                             auc_ahp=ext_auc(AHP_W), auc_oracle=ext_auc(beta),
                             pert_mean=float(np.mean(pert)), pert_min=float(np.min(pert)),
                             pert_max=float(np.max(pert)),
                             dir_mean=float(np.mean(dirich)), dir_min=float(np.min(dirich)),
                             dir_max=float(np.max(dirich))))
            pd.DataFrame(rows).to_csv(effect_path, index=False)
            print(f"AHP weight effect truth={truth} rep={rep} checkpointed", flush=True)
    print("ahp done")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    {"main": phase_main, "shap": phase_shap, "shift": phase_shift,
     "scaling": phase_scaling, "ahp": phase_ahp, "nonlinear": phase_nonlinear}[sys.argv[1]]()
    import scipy, sklearn, matplotlib
    json.dump(dict(numpy=np.__version__, pandas=pd.__version__, scipy=scipy.__version__,
                   scikit_learn=sklearn.__version__, matplotlib=matplotlib.__version__,
                   openpyxl=openpyxl.__version__, python=sys.version.split()[0]),
              open(f"{OUT}/env_{sys.argv[1]}.json", "w"))
