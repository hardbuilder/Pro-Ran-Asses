"""Generate every LaTeX table of the paper directly from the result files (no hand-typed numbers)."""
import json, os
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
R = str(ROOT / "results")
T = str(ROOT / "paper" / "tables")
os.makedirs(T, exist_ok=True)
S = json.load(open(f"{R}/summary.json"))
M4 = ["Raw total", "AHP-weighted", "LR", "RF"]
HDR = {"Raw total": "Raw total", "AHP-weighted": "AHP-wtd.", "LR": "LR", "RF": "RF"}


def tci(x):
    x = np.asarray(x, float)
    m = x.mean()
    h = stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return m, m - h, m + h


def w(name, s):
    open(f"{T}/{name}.tex", "w").write(s + "\n")


df = pd.read_csv(f"{R}/main.csv")
df["auc_ext"] = 0.5 * (df.auc_low + df.auc_high)

# ---- Table: pooled main results ----
rows = []
for bal in ["balanced", "imbalanced"]:
    for noise in [0.5, 1.0, 2.0]:
        sub = df[(df.balance == bal) & (df.noise == noise)]
        cells = []
        for m in M4:
            g = sub[sub.method == m]
            cells.append(f"{g.macroF1.mean():.3f}/{g.auc_ext.mean():.3f}")
        maj = sub[sub.method == "Majority"].macroF1.mean()
        rows.append(f"{bal} & {noise:g} & {maj:.3f} & " + " & ".join(cells) + r" \\")
w("main_pooled", "\n".join(rows))

# ---- Table: full per-scenario (appendix) ----
rows = []
for bal in ["balanced", "imbalanced"]:
    for truth in ["equal", "ahp", "reversed", "random"]:
        for noise in [0.5, 1.0, 2.0]:
            sub = df[(df.balance == bal) & (df.truth == truth) & (df.noise == noise)]
            cells = [f"{sub[sub.method == m].macroF1.mean():.3f}/{sub[sub.method == m].auc_ext.mean():.3f}"
                     for m in M4]
            rows.append(f"{bal} & {truth} & {noise:g} & " + " & ".join(cells) + r" \\")
w("main_full", "\n".join(rows))

# ---- Table: paired differences, balanced, noise 1.0 ----
dd = pd.read_csv(f"{R}/paired_differences.csv")
rows = []
contrasts = [("AHP-weighted", "Raw total"), ("LR", "Raw total"), ("RF", "Raw total")]
for truth in ["equal", "ahp", "reversed", "random"]:
    cells = []
    for a, b in contrasts:
        for met in ["auc_ext", "macroF1"]:
            r = dd[(dd.balance == "balanced") & (dd.noise == 1.0) & (dd.truth == truth) &
                   (dd.a == a) & (dd.b == b) & (dd.metric == met)].iloc[0]
            star = r"$^{*}$" if r.excl0 else ""
            cells.append(f"{r['mean']:+.3f}{star}")
    rows.append(f"{truth} & " + " & ".join(cells) + r" \\")
w("paired", "\n".join(rows))

# overall extremes of paired differences (all 24 scenarios) for the text
ext = {}
for (a, b, met), g in dd.groupby(["a", "b", "metric"]):
    ext[f"{a}|{b}|{met}"] = dict(min=float(g["mean"].min()), max=float(g["mean"].max()),
                                  mean=float(g["mean"].mean()), n=int(len(g)),
                                  n_excl=int(g.excl0.sum()))
json.dump(ext, open(f"{R}/paired_extremes.json", "w"), indent=1)

# ---- Table: size shift ----
sh = pd.read_csv(f"{R}/shift.csv")
sh["auc_ext"] = 0.5 * (sh.auc_low + sh.auc_high)
rows = []
for m in M4:
    a = sh[(sh.method == m) & (sh.setting == "in-distribution")].set_index("rep")
    b = sh[(sh.method == m) & (sh.setting.str.startswith("shifted"))].set_index("rep")
    d = (b.macroF1 - a.macroF1).values
    dm, lo, hi = tci(d)
    rows.append(f"{HDR[m]} & {a.macroF1.mean():.3f} & {b.macroF1.mean():.3f} & {dm:+.3f} [{lo:+.3f}, {hi:+.3f}] & "
                f"{a.auc_ext.mean():.3f} & {b.auc_ext.mean():.3f}" + r" \\")
w("shift", "\n".join(rows))

# ---- Table: scaling ----
sc = pd.read_csv(f"{R}/scaling.csv")
sc["auc_ext"] = 0.5 * (sc.auc_low + sc.auc_high)
rows = []
for n in [200, 500, 1000, 3000, 5000]:
    cells = []
    for m in M4:
        g = sc[(sc.n == n) & (sc.method == m)]
        cells.append(f"{g.macroF1.mean():.3f} ({g.macroF1.std(ddof=1):.3f})")
    rows.append(f"{n} & " + " & ".join(cells) + r" \\")
w("scaling", "\n".join(rows))

# ---- Table: nonlinear ----
nl = pd.read_csv(f"{R}/nonlinear.csv")
nl["auc_ext"] = 0.5 * (nl.auc_low + nl.auc_high)
rows = []
nl_diffs = []
for (t, mix, no), g in nl.groupby(["truth", "nl_mix", "noise"]):
    p = g.pivot(index="rep", columns="method", values=["macroF1", "auc_ext"])
    cells = [f"{p['macroF1'][m].mean():.3f}/{p['auc_ext'][m].mean():.3f}" for m in M4]
    d, lo, hi = tci((p["auc_ext"]["RF"] - p["auc_ext"]["Raw total"]).values)
    nl_diffs.append(d)
    star = r"$^{*}$" if (lo > 0 or hi < 0) else ""
    rows.append(f"{t} & {mix:g} & {no:g} & " + " & ".join(cells) + f" & {d:+.3f}{star}" + r" \\")
w("nonlinear", "\n".join(rows))
json.dump(dict(rf_minus_raw_auc_min=float(min(nl_diffs)), rf_minus_raw_auc_max=float(max(nl_diffs))),
          open(f"{R}/nonlinear_summary.json", "w"))


# ---- Table: SHAP recovery ----
def cell(v):
    m, lo, hi = v
    if np.isnan(m):
        return "n/a"
    if np.isnan(lo):
        return f"{m:+.2f}"
    return f"{m:+.2f} [{lo:+.2f}, {hi:+.2f}]"


rows = []
for truth in ["equal", "ahp", "reversed", "random"]:
    cells = []
    for col in ["rho_dim_truth", "rho_dim_ahp", "rho_q_ahp"]:
        for model in ["LR", "RF"]:
            r = [x for x in S["shap"] if x["truth"] == truth and x["model"] == model][0]
            cells.append(cell(r[col]))
    rows.append(f"{truth} & " + " & ".join(cells) + r" \\")
w("shap", "\n".join(rows))

# ---- Table: AHP perturbation ----
rows = []
for p in S["ahp_perturbation"]:
    rows.append(f"{p['sigma']:g} & {p['mean_CR']:.3f} & {100*p['frac_CR_lt_0p10']:.0f}\\% & "
                f"{p['mean_tau']:.2f} & {100*p['top3_unchanged']:.0f}\\%" + r" \\")
w("ahp_pert", "\n".join(rows))

rows = []
for r in S["weight_effect"]:
    rows.append(f"{r['truth']} & {r['auc_equal']:.3f} & {r['auc_ahp']:.3f} & {r['auc_oracle']:.3f} & "
                f"{r['pert_min']:.3f}--{r['pert_max']:.3f} & {r['dir_min']:.3f}--{r['dir_max']:.3f}" + r" \\")
w("weight_effect", "\n".join(rows))
print("tables written:", sorted(os.listdir(T)))


# ---- dimension-level SHAP: summed vs per-item aggregation (item-count sensitivity) ----
from scipy.stats import spearmanr
sp = pd.read_csv(f"{R}/shap.csv")
Q = np.array([3, 3, 2, 2, 2, 2, 3, 2])
A = np.array([0.2167136289302809, 0.1798514021391615, 0.1567102764061465, 0.1173499618507830, 0.08113824826439145, 0.07020001292117321, 0.1384569354173583, 0.03957953407070507])
agg = {}
for truth in ["equal", "ahp", "reversed", "random"]:
    for model in ["LR", "RF"]:
        g = sp[(sp.truth == truth) & (sp.model == model)]
        res = {"sum_vs_ahp": [], "peritem_vs_ahp": [], "sum_vs_truth": [], "peritem_vs_truth": []}
        for _, row in g.iterrows():
            sh = np.array(json.loads(row.shares)); b = np.array(json.loads(row.beta)); per = sh / Q
            res["sum_vs_ahp"].append(spearmanr(sh, A)[0]); res["peritem_vs_ahp"].append(spearmanr(per, A)[0])
            if b.std() > 0:
                res["sum_vs_truth"].append(spearmanr(sh, b)[0]); res["peritem_vs_truth"].append(spearmanr(per, b)[0])
        agg[f"{truth}|{model}"] = {k: (list(map(float, tci(v))) if len(v) > 1 else None) for k, v in res.items()}
json.dump(agg, open(f"{R}/shap_peritem.json", "w"), indent=1)
